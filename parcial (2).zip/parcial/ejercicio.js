
var dulces = [
    { nombre: 'Chocolate', color: 'Marrón', sabor: 'Dulce', precio: 5.000, cantidad: 10 },
    { nombre: 'Caramelo', color: 'Amarillo', sabor: 'Frutal', precio: 3.000, cantidad: 5 },
    { nombre: 'Galleta', color: 'Beige', sabor: 'Vainilla', precio: 2.000, cantidad: 8 },
    { nombre: 'Malvavisco', color: 'Blanco', sabor: 'Malva', precio: 5.000, cantidad: 15 }
  ];
  

  for (var i = 0; i < dulces.length; i++) {
    console.log('Dulce ' + (i + 1) + ':');
    console.log('Nombre: ' + dulces[i].nombre);
    console.log('Color: ' + dulces[i].color);
    console.log('Sabor: ' + dulces[i].sabor);
    console.log('Precio: $' + dulces[i].precio);
    console.log('Cantidad: ' + dulces[i].cantidad);
    console.log('------------------------------');
  }
  